# Generated file
NETPLAN_FEATURE_FLAGS = [
    "auth-phase2",
    "dhcp-use-domains",
    "ipv6-mtu",
    "generated-supplicant",
]
