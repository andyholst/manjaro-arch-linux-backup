! -*- fortran -*-
!
! Copyright (c) 2010-2011 Oak Ridge National Labs.  All rights reserved.
! Copyright (c) 2012      Cisco Systems, Inc.  All rights reserved.
! Copyright (c) 2018      Research Organization for Information Science
!                         and Technology (RIST).  All rights reserved.
! $COPYRIGHT$
!
! Additional copyrights may follow
!
! $HEADER$
!

! Since the OMPI mpif.h interface does not prototype subroutines, do not
! declare any subroutines here.
