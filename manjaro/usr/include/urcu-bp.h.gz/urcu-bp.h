#define URCU_API_MAP
#include <urcu/urcu-bp.h>
