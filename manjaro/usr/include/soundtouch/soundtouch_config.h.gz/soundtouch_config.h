/* include/soundtouch_config.h.  Generated from soundtouch_config.h.in by configure.  */
/* Use Float as Sample type */
#define SOUNDTOUCH_FLOAT_SAMPLES 1

/* Use Integer as Sample type */
/* #undef SOUNDTOUCH_INTEGER_SAMPLES */

/* Use ARM NEON extension */
/* #undef SOUNDTOUCH_USE_NEON */
