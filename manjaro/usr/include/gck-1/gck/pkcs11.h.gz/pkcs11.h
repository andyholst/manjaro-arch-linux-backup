#warning "gck/pkcs11.h is deprecated.  Use p11-kit/pkcs11.h instead."

#include <p11-kit/pkcs11.h>
