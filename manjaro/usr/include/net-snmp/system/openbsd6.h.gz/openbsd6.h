/* openbsd6 is a superset of all since openbsd3 */
#include "openbsd5.h"
#define openbsd5 openbsd5
