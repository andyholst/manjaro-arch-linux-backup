/* Everything that is specific to Cygwin is detected by the configure script */
