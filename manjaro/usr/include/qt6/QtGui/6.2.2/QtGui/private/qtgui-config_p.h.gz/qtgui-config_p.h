#define QT_FEATURE_accessibility_atspi_bridge 1

#define QT_FEATURE_directfb -1

#define QT_FEATURE_directwrite -1

#define QT_FEATURE_directwrite3 -1

#define QT_FEATURE_direct2d -1

#define QT_FEATURE_direct2d1_1 -1

#define QT_FEATURE_evdev 1

#define QT_FEATURE_freetype 1

#define QT_FEATURE_system_freetype 1

#define QT_FEATURE_fontconfig 1

#define QT_FEATURE_harfbuzz 1

#define QT_FEATURE_system_harfbuzz 1

#define QT_FEATURE_qqnx_imf -1

#define QT_FEATURE_integrityfb -1

#define QT_FEATURE_kms 1

#define QT_FEATURE_drm_atomic 1

#define QT_FEATURE_libinput 1

#define QT_FEATURE_integrityhid -1

#define QT_FEATURE_libinput_axis_api 1

#define QT_FEATURE_linuxfb 1

#define QT_FEATURE_vsp2 -1

#define QT_FEATURE_vnc 1

#define QT_FEATURE_mtdev 1

#define QT_FEATURE_vkgen 1

#define QT_FEATURE_vkkhrdisplay 1

#define QT_FEATURE_egl_x11 1

#define QT_FEATURE_eglfs 1

#define QT_FEATURE_eglfs_brcm -1

#define QT_FEATURE_eglfs_egldevice 1

#define QT_FEATURE_eglfs_gbm 1

#define QT_FEATURE_eglfs_vsp2 -1

#define QT_FEATURE_eglfs_mali -1

#define QT_FEATURE_eglfs_viv -1

#define QT_FEATURE_eglfs_rcar -1

#define QT_FEATURE_eglfs_viv_wl -1

#define QT_FEATURE_eglfs_openwfd -1

#define QT_FEATURE_eglfs_x11 1

#define QT_FEATURE_gif 1

#define QT_FEATURE_ico 1

#define QT_FEATURE_jpeg 1

#define QT_FEATURE_system_jpeg 1

#define QT_FEATURE_png 1

#define QT_FEATURE_system_png 1

#define QT_FEATURE_imageio_text_loading 1

#define QT_FEATURE_tslib 1

#define QT_FEATURE_tuiotouch 1

#define QT_FEATURE_xcb_glx 1

#define QT_FEATURE_xcb_egl_plugin 1

#define QT_FEATURE_xcb_native_painting -1

#define QT_FEATURE_xrender -1

#define QT_FEATURE_xcb_xlib 1

#define QT_FEATURE_xcb_sm 1

#define QT_FEATURE_system_xcb_xinput 1

#define QT_FEATURE_xkbcommon 1

#define QT_FEATURE_xkbcommon_x11 1

#define QT_FEATURE_xlib 1

#define QT_FEATURE_multiprocess 1

#define QT_FEATURE_raster_64bit 1

#define QT_FEATURE_raster_fp 1

