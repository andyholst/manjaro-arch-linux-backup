#define QT_FEATURE_quickcontrols2_basic 1

#define QT_FEATURE_quickcontrols2_fusion 1

#define QT_FEATURE_quickcontrols2_imagine 1

#define QT_FEATURE_quickcontrols2_material 1

#define QT_FEATURE_quickcontrols2_universal 1

#define QT_FEATURE_quickcontrols2_macos 1

#define QT_FEATURE_quickcontrols2_windows 1

