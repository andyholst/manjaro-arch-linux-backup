#define QT_FEATURE_testlib_selfcover -1

#define QT_FEATURE_itemmodeltester 1

#define QT_FEATURE_valgrind 1

