#define QT_FEATURE_quick_animatedimage 1

#define QT_FEATURE_quick_canvas 1

#define QT_FEATURE_quick_designer 1

#define QT_FEATURE_quick_flipable 1

#define QT_FEATURE_quick_gridview 1

#define QT_FEATURE_quick_itemview 1

#define QT_FEATURE_quick_viewtransitions 1

#define QT_FEATURE_quick_listview 1

#define QT_FEATURE_quick_tableview 1

#define QT_FEATURE_quick_particles 1

#define QT_FEATURE_quick_path 1

#define QT_FEATURE_quick_pathview 1

#define QT_FEATURE_quick_positioners 1

#define QT_FEATURE_quick_repeater 1

#define QT_FEATURE_quick_shadereffect 1

#define QT_FEATURE_quick_sprite 1

