#define QT_FEATURE_getifaddrs 1

#define QT_FEATURE_ipv6ifname 1

#define QT_FEATURE_securetransport -1

#define QT_FEATURE_schannel -1

#define QT_FEATURE_ssl 1

#define QT_FEATURE_dtls 1

#define QT_FEATURE_ocsp 1

#define QT_FEATURE_opensslv11 1

#define QT_FEATURE_sctp -1

#define QT_FEATURE_http 1

#define QT_FEATURE_udpsocket 1

#define QT_FEATURE_networkproxy 1

#define QT_FEATURE_socks5 1

#define QT_FEATURE_networkinterface 1

#define QT_FEATURE_networkdiskcache 1

#define QT_FEATURE_brotli 1

#define QT_FEATURE_localserver 1

#define QT_FEATURE_dnslookup 1

#define QT_FEATURE_gssapi 1

#define QT_FEATURE_sspi -1

#define QT_FEATURE_topleveldomain 1

#define QT_LINKED_OPENSSL
#define QT_NO_SCTP 1
#define QT_NO_SSPI 1
