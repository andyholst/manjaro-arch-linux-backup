#define QT_FEATURE_quicktemplates2_hover 1

#define QT_FEATURE_quicktemplates2_multitouch 1

