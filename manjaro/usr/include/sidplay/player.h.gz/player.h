//
// /home/ms/source/sidplay/libsidplay/include/RCS/player.h,v
//

#ifndef SIDPLAY1_PLAYER_H
#define SIDPLAY1_PLAYER_H


#include "compconf.h"
#include "mytypes.h"
#include "emucfg.h"
#include "sidtune.h"
#include "version.h"


#endif  /* SIDPLAY1_PLAYER_H */
