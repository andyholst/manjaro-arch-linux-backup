/* src/mms_config.h.  Generated from mms_config.h.in by configure.  */
/* libmms public autoconf settings header file */

/* Define to 1 if libmms is compiled with 64 bit file offsets */
#define LIBMMS_HAVE_64BIT_OFF_T 1
