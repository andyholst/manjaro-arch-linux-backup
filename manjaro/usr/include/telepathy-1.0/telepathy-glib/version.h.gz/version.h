/* telepathy-glib/version.h.  Generated from version.h.in by configure. */

#define TP_MAJOR_VERSION 0
#define TP_MINOR_VERSION 24
#define TP_MICRO_VERSION 2
