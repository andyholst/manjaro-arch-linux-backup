#ifndef __TP_ENUMS_H__
#define __TP_ENUMS_H__

#if defined (TP_DISABLE_SINGLE_INCLUDE) && !defined (_TP_IN_META_HEADER) && !defined (_TP_COMPILATION)
#error "Only <telepathy-glib/telepathy-glib.h> and <telepathy-glib/telepathy-glib-dbus.h> can be included directly."
#endif

#include <telepathy-glib/_gen/telepathy-enums.h>
#include <telepathy-glib/_gen/genums.h>

#endif
