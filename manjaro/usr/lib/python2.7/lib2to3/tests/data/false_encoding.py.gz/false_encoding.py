#!/usr/bin/env python2
print '#coding=0'
