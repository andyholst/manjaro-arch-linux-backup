#
# This file is part of application-utility.
#
# application-utility is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# application-utility is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with application-utility.  If not, see <http://www.gnu.org/licenses/>.
#
# Authors: papajoke
#          fhdk
import logging
import os
import requests
import sys

from .config import Config

from application_utility.translation import i18n

_ = i18n.language.gettext


class AppConfig(Config):
    """
    for Stand-alone application
    """

    def load(self):
        """ load file or url by parameter console"""
        self.pref = {"data-set": "default"}
        self.url = {"desktop": "", "main": ""}
        self.file = {"desktop": "", "main": f"{self._DATA_DIR}/default.json"}
        self.file["main"] = self.get_datafile(self.file["main"], "file")
        return self
