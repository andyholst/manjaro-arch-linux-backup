package example2

type MyStruct struct {
	MyStructs []MyStruct
	MyStruct  *MyStruct
}
