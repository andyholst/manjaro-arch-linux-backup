This file should not be parsed by ParseDir.
