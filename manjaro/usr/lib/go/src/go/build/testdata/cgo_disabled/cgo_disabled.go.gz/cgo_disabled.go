package cgo_disabled

import "C"

import _ "should/be/ignored"
