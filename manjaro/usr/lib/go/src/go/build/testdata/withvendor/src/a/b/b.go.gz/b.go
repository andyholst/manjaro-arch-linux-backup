package b

import _ "c/d"
