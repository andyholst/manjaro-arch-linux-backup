// Doc from xtests
package doc_test
