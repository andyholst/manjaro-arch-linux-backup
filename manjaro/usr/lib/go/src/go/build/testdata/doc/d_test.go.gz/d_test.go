// Doc from regular tests.
package doc
