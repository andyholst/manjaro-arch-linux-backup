static void f1()
{
	char buf[10];
	int i;
	for(i = 0; i < 10; i++)
		buf[i] = 1;
}
