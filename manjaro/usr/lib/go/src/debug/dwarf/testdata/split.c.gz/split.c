// gcc -gsplit-dwarf split.c -o split.elf

int main() 
{
}
