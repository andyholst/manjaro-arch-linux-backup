#include "line1.h"

void f2();

int main()
{
	f1();
	f2();
}
