package illumos

import _ "d"
