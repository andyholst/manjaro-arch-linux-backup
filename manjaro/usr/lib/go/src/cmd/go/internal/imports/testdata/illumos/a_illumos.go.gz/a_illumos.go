package illumos

import _ "a"
