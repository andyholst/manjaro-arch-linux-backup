// +build illumos

package illumos

import _ "e"
