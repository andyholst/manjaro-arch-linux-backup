package illumos

import _ "c"
