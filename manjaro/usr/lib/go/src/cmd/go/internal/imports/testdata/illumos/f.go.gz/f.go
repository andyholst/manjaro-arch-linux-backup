// +build solaris

package illumos

import _ "f"
