// +build android

package android

import _ "e"
