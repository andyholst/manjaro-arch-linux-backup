// +build !illumos

package illumos

import _ "g"
