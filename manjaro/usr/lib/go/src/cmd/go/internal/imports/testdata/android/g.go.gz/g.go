// +build !android

package android

import _ "g"
