// +build linux

package android

import _ "f"
