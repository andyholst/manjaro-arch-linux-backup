package p1

import _ "old/p2"
import _ "new/p1"
import _ "new"
