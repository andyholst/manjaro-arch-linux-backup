package new

import _ "new/v2/p2"
