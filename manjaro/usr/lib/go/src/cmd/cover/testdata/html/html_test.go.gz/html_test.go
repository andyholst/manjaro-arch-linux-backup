package html

import "testing"

func TestAll(t *testing.T) {
	f()
	g()
}
