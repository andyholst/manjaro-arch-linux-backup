package main

import "C"

//export GoFunc
func GoFunc() {}

func main() {}
