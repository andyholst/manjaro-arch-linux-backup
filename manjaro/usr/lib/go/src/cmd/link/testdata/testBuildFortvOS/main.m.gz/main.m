extern void GoFunc();

int main(int argc, char **argv) {
	GoFunc();
}
