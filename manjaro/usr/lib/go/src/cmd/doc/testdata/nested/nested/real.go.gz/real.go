package nested

type Foo struct {
}
