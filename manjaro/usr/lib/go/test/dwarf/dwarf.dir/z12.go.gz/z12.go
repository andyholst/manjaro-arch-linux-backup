
//line x12.go:4
package main
func F12() {}
