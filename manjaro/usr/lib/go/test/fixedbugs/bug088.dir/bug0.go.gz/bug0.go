// Copyright 2009 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package bug0

var V0 func() int;
var V1 func() (a int);
var V2 func() (a, b int);
