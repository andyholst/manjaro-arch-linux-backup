// Copyright 2019 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package a

func A() int {
	return p("count")
}

func p(which string, args ...string) int {
	switch which {
	case "count", "something":
		return 1
	default:
		return 2
	}
}
