// compiledir

// Copyright 2020 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Issue 35739: gccgo inlining error with constant with method.

package ignored
