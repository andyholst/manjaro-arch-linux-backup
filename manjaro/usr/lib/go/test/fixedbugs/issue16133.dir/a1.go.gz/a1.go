package a

type X string

func NewX() X {
	return ""
}
