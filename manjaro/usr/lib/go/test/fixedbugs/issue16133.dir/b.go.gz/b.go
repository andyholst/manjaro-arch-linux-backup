package b

import "./a2"

type T struct {
	X a.X
}
