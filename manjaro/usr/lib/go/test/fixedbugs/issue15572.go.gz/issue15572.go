// compiledir

// Copyright 2016 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Test that exporting composite literals with implicit
// types doesn't crash the typechecker when running over
// inlined function bodies containing such literals.

package ignored
