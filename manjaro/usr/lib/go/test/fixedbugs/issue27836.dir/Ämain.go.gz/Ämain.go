package main

import (
	"fmt"

	"./Äfoo"
	Äblix "./Äfoo"
)

func main() {
	fmt.Printf("Äfoo.Äbar(33) returns %v\n", Äfoo.Äbar(33))
	fmt.Printf("Äblix.Äbar(33) returns %v\n", Äblix.Äbar(33))
}
