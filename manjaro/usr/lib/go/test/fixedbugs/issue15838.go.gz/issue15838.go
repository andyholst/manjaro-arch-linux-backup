// compiledir

// Copyright 2016 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Test cases for issue #15838, and related failures.
// Make sure the importer correctly sets up nodes for
// label decls, goto, continue, break, and fallthrough
// statements.

package ignored
