// rundir

// Copyright 2012 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// The reflect package was not correctly checking field names
// when checking for struct assignability.

package ignored
