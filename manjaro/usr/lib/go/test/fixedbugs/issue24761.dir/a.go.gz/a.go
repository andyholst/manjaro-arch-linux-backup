// Copyright 2018 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package a

type T2 struct{}

func (t *T2) M2(a, b float64) {
	variadic(a, b)
}

func variadic(points ...float64) {
	println(points)
}
