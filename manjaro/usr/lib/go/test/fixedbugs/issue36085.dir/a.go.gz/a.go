package a

type W = map[int32]interface{}
