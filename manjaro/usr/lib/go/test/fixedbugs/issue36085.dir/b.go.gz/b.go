package main

import "a"

var w a.W
var X interface{} = &w

func main() {}
