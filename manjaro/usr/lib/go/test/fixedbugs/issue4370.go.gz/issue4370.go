// compiledir

// Copyright 2012 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Re-exporting inlined function bodies missed types in x, ok := v.(Type)

package ignored
