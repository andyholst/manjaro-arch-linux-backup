// compiledir

// Copyright 2019 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// This directory contains a pair of packages that triggers a compiler
// error in gccgo (problem with the way inlinable call expressions are
// imported). See issue 32922 for details.

package ignored
