package b

import _ "./a" // must not fail
