package x

import "./rethinkgo"

var S *rethinkgo.Session


