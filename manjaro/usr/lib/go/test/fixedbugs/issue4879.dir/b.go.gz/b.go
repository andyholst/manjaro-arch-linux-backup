package b

import "./a"

func F() {
      a.MakePrivateCollection()
      a.MakePrivateCollection2()
      a.MakePrivateCollection3()
}
