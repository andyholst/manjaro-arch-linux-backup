// Copyright 2019 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package a

var G1 int
var G2 int
var G3 int
var G4 int
var G5 int
var G6 int
var G7 int
var G8 int
var G9 int
var G10 int
