import relativeDateFactory from './factory'
import enTranslations from '../translations/en'

export default relativeDateFactory(enTranslations)
