module.exports = {
	L : 1,
	M : 0,
	Q : 3,
	H : 2
};

