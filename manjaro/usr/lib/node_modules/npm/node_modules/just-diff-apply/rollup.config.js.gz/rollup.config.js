const createRollupConfig = require('../../config/createRollupConfig');

module.exports = createRollupConfig(__dirname);
