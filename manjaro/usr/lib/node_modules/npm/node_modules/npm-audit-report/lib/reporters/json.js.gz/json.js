module.exports = (data, { indent }) => JSON.stringify(data, null, indent)
