module.exports = {
  clone: require('./clone.js'),
  revs: require('./revs.js'),
  spawn: require('./spawn.js'),
  is: require('./is.js'),
  find: require('./find.js'),
  isClean: require('./is-clean.js'),
  errors: require('./errors.js')
}
