module.exports = () => !process.stdin.isTTY
