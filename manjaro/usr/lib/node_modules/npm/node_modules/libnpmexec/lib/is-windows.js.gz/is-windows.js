module.exports = process.platform === 'win32'
