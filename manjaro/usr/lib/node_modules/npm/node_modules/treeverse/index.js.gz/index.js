module.exports = {
  breadth: require('./lib/breadth.js'),
  depth: require('./lib/depth.js'),
}
