export function distance(a: string, b: string): number;
export function closest(str: string, arr: string[]): string;