#!/usr/bin/env node
require('./corepack').runMain(['pnpm', ...process.argv.slice(2)]);
