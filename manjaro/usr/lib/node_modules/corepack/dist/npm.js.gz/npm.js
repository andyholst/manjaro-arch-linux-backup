#!/usr/bin/env node
require('./corepack').runMain(['npm', ...process.argv.slice(2)]);
