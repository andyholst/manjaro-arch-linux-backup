#!/usr/bin/env node
require('./corepack').runMain(['yarnpkg', ...process.argv.slice(2)]);
