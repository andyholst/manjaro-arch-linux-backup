#!/usr/bin/env node
require('./corepack').runMain(['npx', ...process.argv.slice(2)]);
