#!/usr/bin/env node
require('./corepack').runMain(['pnpx', ...process.argv.slice(2)]);
