#!/usr/bin/env node
require('./corepack').runMain(['yarn', ...process.argv.slice(2)]);
