const envPaths = require('env-paths')

module.exports.devDir = () => envPaths('node-gyp', { suffix: '' }).cache
