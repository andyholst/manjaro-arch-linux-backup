var indexSectionsWithContent =
{
  0: "degmopr",
  1: "o",
  2: "o",
  3: "o",
  4: "o",
  5: "degmopr",
  6: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "defines",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Typedefs",
  4: "Macros",
  5: "Modules",
  6: "Pages"
};

