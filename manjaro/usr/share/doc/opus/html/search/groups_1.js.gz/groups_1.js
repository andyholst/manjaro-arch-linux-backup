var searchData=
[
  ['encoder_20related_20ctls_273',['Encoder related CTLs',['../group__opus__encoderctls.html',1,'']]],
  ['error_20codes_274',['Error codes',['../group__opus__errorcodes.html',1,'']]]
];
