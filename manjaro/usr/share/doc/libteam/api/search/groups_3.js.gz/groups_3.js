var searchData=
[
  ['team_20options_20functions_0',['Team options functions',['../group__option.html',1,'']]],
  ['team_20ports_20functions_1',['Team ports functions',['../group__ports.html',1,'']]]
];
