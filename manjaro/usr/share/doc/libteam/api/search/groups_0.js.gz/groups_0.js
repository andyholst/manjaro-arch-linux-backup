var searchData=
[
  ['interface_20information_20functions_0',['Interface information functions',['../group__ifinfo.html',1,'']]]
];
