# alsa-topology-conf
ALSA topology configuration files

Use 'make firmware' to compile and install the topology files
to the /lib/firmware tree.
