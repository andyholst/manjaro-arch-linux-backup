# VPNC <a href="https://davidepucci.it/doc/vpnc"><img align="left" src="https://davidepucci.it/favicon/favicon-96x96.png"></a>

Documentation available at [davidepucci.it/doc/vpnc](https://davidepucci.it/doc/vpnc).
