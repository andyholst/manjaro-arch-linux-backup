Sratom
======

Sratom is a small library for serialising LV2 atoms to and from RDF, for
converting between binary and text or storing in a model.  For more
information, see <http://drobilla.net/software/sratom>.

More information about LV2 atoms can be found at
<http://lv2plug.in/ns/ext/atom>

 -- David Robillard <d@drobilla.net>
