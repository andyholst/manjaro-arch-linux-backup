var PACKAGE_VERSION = 48;
var PACKAGE_URL = 'https://github.com/andyholmes/gnome-shell-extension-gsconnect';
var PACKAGE_BUGREPORT = 'https://github.com/andyholmes/gnome-shell-extension-gsconnect/issues/new';
var PACKAGE_DATADIR = '/usr/share/gnome-shell/extensions/gsconnect@andyholmes.github.io';
var PACKAGE_LOCALEDIR = '/usr/share/locale';
var GSETTINGS_SCHEMA_DIR = '/usr/share/glib-2.0/schemas';
var GNOME_SHELL_LIBDIR = '/usr/lib';

var APP_ID = 'org.gnome.Shell.Extensions.GSConnect';
var APP_PATH = '/org/gnome/Shell/Extensions/GSConnect';

var IS_USER = false;

// External binary paths
var OPENSSL_PATH = 'openssl';
var SSHADD_PATH = 'ssh-add';
var SSHKEYGEN_PATH = 'ssh-keygen';
var FFMPEG_PATH = 'ffmpeg';

