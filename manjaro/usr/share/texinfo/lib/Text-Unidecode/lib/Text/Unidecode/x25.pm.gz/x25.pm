# Time-stamp: "Sat Jul 14 00:27:23 2001 by Automatic Bizooty (__blocks2pm.plx)"
$Text::Unidecode::Char[0x25] = [
qq{-}, qq{-}, qq{|}, qq{|}, qq{-}, qq{-}, qq{|}, qq{|}, qq{-}, qq{-}, qq{|}, qq{|}, qq{+}, qq{+}, qq{+}, qq{+},
qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+},
qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+},
qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+},
qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{-}, qq{-}, qq{|}, qq{|},
qq{-}, qq{|}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+},
qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+}, qq{+},
qq{+}, qq{/}, qq{\\}, 'X', qq{-}, qq{|}, qq{-}, qq{|}, qq{-}, qq{|}, qq{-}, qq{|}, qq{-}, qq{|}, qq{-}, qq{|},
qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#},
qq{#}, qq{#}, qq{#}, qq{#}, qq{-}, qq{|}, '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]',
qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#},
qq{#}, qq{#}, qq{^}, qq{^}, qq{^}, qq{^}, qq{>}, qq{>}, qq{>}, qq{>}, qq{>}, qq{>}, 'V', 'V', 'V', 'V',
qq{<}, qq{<}, qq{<}, qq{<}, qq{<}, qq{<}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*},
qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*},
qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{*}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{^}, qq{^}, qq{^}, 'O',
qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, qq{#}, '[?]', '[?]', '[?]', '[?]', '[?]', '[?]', '[?]',
];
1;
