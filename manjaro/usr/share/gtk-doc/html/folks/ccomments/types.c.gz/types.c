/**
 * FolksMaybeBool:
 * @FOLKS_MAYBE_BOOL_UNSET: This value is explicitly unset.
 * @FOLKS_MAYBE_BOOL_FALSE: False (this value was set from its default of UNSET).
 * @FOLKS_MAYBE_BOOL_TRUE: True (this value was set from its default of UNSET).
 * 
 * A &apos;boolean&apos; type that has a distinct &apos;unset&apos; state.
 *
 * Since: 0.3.1
 */
