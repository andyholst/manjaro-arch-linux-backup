# plymouth-manjaro

Plymouth theme for manjaro