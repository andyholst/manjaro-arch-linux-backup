--
-- Use libstemmer for stemming rather than SQLite.
--

DROP TABLE IF EXISTS TokenizerTable;
