package URI::sftp;

use strict;
use warnings;

use parent 'URI::ssh';

our $VERSION = '5.10';

1;
