+{
   locale_version => 1.29,
   entry => <<'ENTRY', # for DUCET v13.0.0
0149      ; [.2118.0020.0009] # LATIN SMALL LETTER N PRECEDED BY APOSTROPHE
ENTRY
};
