use strict;
use warnings;
package perlfaq;

our $VERSION = '5.20210411';

1;
