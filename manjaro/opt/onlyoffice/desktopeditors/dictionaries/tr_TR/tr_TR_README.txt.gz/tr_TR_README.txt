﻿This is a wordlist based turkish spell checker. Due to the nature of turkish, this approach is not well suited
as morphological parser based mechanisms. When high accuracy is needed, such a mechanism should be preferred
(eg. zemberek project)

