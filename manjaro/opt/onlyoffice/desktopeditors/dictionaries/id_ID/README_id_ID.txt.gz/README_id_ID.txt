Copyright (c) 2014 Benitius Brevoort (benitius.brevoort@kapusin.org or benitius@tiscali.it).

Licensed under the terms of any of the following licenses:
- Mozilla Public License 2.0 (MPL-2.0) (see https://opensource.org/licenses/MPL-2.0)
- GNU Lesser General Public License version 3.0 (see https://opensource.org/licenses/LGPL-3.0)

Berkas id_ID.dic dan id_ID.aff diekstrak oleh Arif Budiman (arifpedia@gmail.com) dari ekstensi kamus Bahasa Indonesia untuk LibreOffice (berkas id_id.oxt) di: https://extensions.libreoffice.org/extensions/indonesian-dictionary-kamus-indonesia-by-benitius