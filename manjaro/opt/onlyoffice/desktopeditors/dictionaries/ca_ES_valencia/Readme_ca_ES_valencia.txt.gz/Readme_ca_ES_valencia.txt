LICENSES :
Spelling dictionary: LGPL, GPL
Tesaurus: LGPL, GPL
Hyphenation: LGPL, GPL
